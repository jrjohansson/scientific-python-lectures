#!/usr/bin/env python

print("Hello world!")
